import { Link, useLocation } from "@tanstack/react-router";

const links = [
  { to: "/", label: "HOME" },
  { to: "/about", label: "ABOUT" },
  { to: "/skills", label: "SKILLS" },
  { to: "/experience", label: "EXPERIENCE" },
  { to: "/services", label: "SERVICES" },
  { to: "/blog", label: "BLOG" },
  { to: "/contact", label: "CONTACT" },
];

export function SiteNav() {
  const { pathname } = useLocation();
  return (
    <header className="relative z-30 flex items-center justify-between px-12 py-7">
      <Link to="/" className="flex items-center gap-3">
        <span className="grid h-9 w-9 place-items-center rounded-md text-[oklch(0.7_0.25_305)]" style={{ boxShadow: "0 0 18px oklch(0.62 0.27 305 / 0.5)" }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" className="h-7 w-7">
            <polyline points="8 6 2 12 8 18" />
            <polyline points="16 6 22 12 16 18" />
          </svg>
        </span>
        <span className="heading-display text-[1.35rem] font-semibold text-white">Avijit Biswas</span>
      </Link>
      <nav className="hidden items-center gap-12 lg:flex">
        {links.map((l) => {
          const active = pathname === l.to;
          return (
            <Link key={l.to} to={l.to} className={`nav-link ${active ? "active" : ""}`}>
              {l.label}
            </Link>
          );
        })}
      </nav>
      <button className="btn-neon">LET'S TALK</button>
    </header>
  );
}
