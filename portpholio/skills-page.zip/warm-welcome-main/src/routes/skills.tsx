import { createFileRoute } from "@tanstack/react-router";
import { SiteNav } from "@/components/SiteNav";
import planet from "@/assets/planet-main.png";
import skillsBg from "@/assets/skills-bg.png";
import learningBg from "@/assets/learning-bg.png";
import { SiReact, SiNextdotjs, SiNodedotjs, SiTypescript, SiJavascript, SiMongodb, SiPostgresql, SiTailwindcss } from "react-icons/si";
import { Quote } from "lucide-react";

export const Route = createFileRoute("/skills")({
  component: SkillsPage,
  head: () => ({
    meta: [
      { title: "Skills — Avijit Biswas" },
      { name: "description", content: "Technologies and tools I work with to build high-quality products." },
    ],
  }),
});

const skills = [
  { name: "React.js", pct: 90, icon: <SiReact className="h-12 w-12" style={{ color: "#61DAFB" }} /> },
  { name: "Next.js", pct: 90, icon: <SiNextdotjs className="h-11 w-11 text-white" /> },
  { name: "Node.js", pct: 90, icon: <SiNodedotjs className="h-12 w-12" style={{ color: "#5FA04E" }} /> },
  { name: "TypeScript", pct: 86, icon: <SiTypescript className="h-11 w-11" style={{ color: "#3178C6" }} /> },
  { name: "JavaScript", pct: 88, icon: <SiJavascript className="h-11 w-11" style={{ color: "#F7DF1E", background: "#000" }} /> },
  { name: "MongoDB", pct: 88, icon: <SiMongodb className="h-12 w-12" style={{ color: "#47A248" }} /> },
  { name: "PostgreSQL", pct: 80, icon: <SiPostgresql className="h-12 w-12" style={{ color: "#4169E1" }} /> },
  { name: "Tailwind CSS", pct: 90, icon: <SiTailwindcss className="h-11 w-11" style={{ color: "#38BDF8" }} /> },
];

const otherTech = ["Git", "GitHub", "VS Code", "Figma", "Docker", "Vercel", "JWT", "Postman", "ESLint", "Prettier", "ShadCN UI", "Framer Motion"];

function SkillsPage() {
  return (
    <div className="relative min-h-screen overflow-hidden" style={{ background: "oklch(0.07 0.03 280)" }}>
      {/* Page-wide starfield bg */}
      <div
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          backgroundImage: `url(${skillsBg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          mixBlendMode: "screen",
        }}
      />
      <div className="pointer-events-none absolute inset-0" style={{ background: "radial-gradient(ellipse at 30% 10%, oklch(0.2 0.08 295 / 0.35), transparent 60%)" }} />

      <div className="relative z-10">
        <SiteNav />

        <main className="px-12 pb-20 pt-6">
          <div className="grid grid-cols-12 gap-10">
            {/* LEFT */}
            <section className="col-span-12 lg:col-span-7 fade-up">
              <p className="mb-5 text-[0.78rem] font-semibold tracking-[0.18em] text-[oklch(0.7_0.25_305)]">
                01. SKILLS
              </p>
              <h1 className="heading-display text-[3.2rem] font-semibold leading-[1.1] text-white">
                Technologies I work with
                <br />
                to bring <span className="neon-text">ideas to life.</span>
              </h1>
              <p className="mt-6 max-w-xl text-[0.98rem] leading-relaxed text-[oklch(0.72_0.02_280)]">
                I love working with modern technologies
                <br />
                and tools to build high-quality products.
              </p>

              {/* Skill cards 4x2 */}
              <div className="mt-10 grid grid-cols-2 gap-5 sm:grid-cols-4">
                {skills.map((s, i) => (
                  <div key={s.name} className="skill-card fade-up" style={{ animationDelay: `${0.1 + i * 0.05}s` }}>
                    <div className="mb-8 flex h-14 items-center">{s.icon}</div>
                    <div className="flex items-baseline justify-between">
                      <span className="text-[0.95rem] font-medium text-white">{s.name}</span>
                      <span className="text-[0.85rem] text-[oklch(0.72_0.02_280)]">{s.pct}%</span>
                    </div>
                    <div className="progress-bar mt-3">
                      <div className="progress-fill" style={{ width: `${s.pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* RIGHT */}
            <aside className="col-span-12 lg:col-span-5">
              {/* Planets */}
              <div className="relative h-[340px] w-full">
                {/* Big planet — slow spin */}
                <div className="absolute right-[-60px] top-[10px] h-[340px] w-[340px] float-y">
                  <img
                    src={planet}
                    alt="Planet"
                    className="spin-slow h-full w-full object-contain"
                    style={{ filter: "drop-shadow(0 0 60px oklch(0.5 0.25 295 / 0.55))" }}
                  />
                </div>
                {/* Small planet — faster spin */}
                <div className="absolute right-[20px] top-[200px] h-[80px] w-[80px]">
                  <img
                    src={planet}
                    alt="Moon"
                    className="spin-fast h-full w-full object-contain"
                    style={{ filter: "drop-shadow(0 0 20px oklch(0.5 0.25 295 / 0.7))" }}
                  />
                </div>
              </div>

              {/* Other Technologies */}
              <div className="mt-10">
                <h3 className="mb-5 text-[1.05rem] font-semibold text-white">Other Technologies</h3>
                <div className="flex flex-wrap gap-2.5">
                  {otherTech.map((t) => (
                    <span key={t} className="tech-pill">{t}</span>
                  ))}
                </div>
              </div>

              {/* Quote card with learning bg */}
              <div
                className="relative mt-8 overflow-hidden rounded-2xl border border-[oklch(1_0_0/0.08)] p-7"
                style={{
                  backgroundImage: `linear-gradient(110deg, oklch(0.09 0.03 280 / 0.92) 0%, oklch(0.09 0.03 280 / 0.55) 55%, oklch(0.09 0.03 280 / 0.1) 100%), url(${learningBg})`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}
              >
                <Quote className="h-8 w-8 text-[oklch(0.7_0.25_305)]" fill="currentColor" />
                <h4 className="mt-3 text-[1.25rem] font-semibold text-white">
                  Always learning, always growing.
                </h4>
                <p className="mt-3 max-w-md text-[0.88rem] leading-relaxed text-[oklch(0.75_0.02_280)]">
                  I'm constantly exploring new technologies and improving
                  <br />
                  my skills to stay ahead in the fast-paced world.
                </p>
              </div>
            </aside>
          </div>
        </main>
      </div>
    </div>
  );
}
