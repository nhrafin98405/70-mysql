import { useState } from "react";
import { Mail, PhoneCall, MapPin, Send, ArrowRight, Github, Linkedin, Twitter, Instagram } from "lucide-react";
import { Navbar } from "./Navbar";
import { StarField } from "./StarField";
import bg from "@/assets/contact-bg.png";
import planet from "@/assets/planet.png";

export function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" });

  return (
    <div className="relative min-h-screen overflow-hidden bg-background text-foreground">
      {/* Background */}
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center opacity-40"
        style={{ backgroundImage: `url(${bg})` }}
      />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background" />
      <StarField count={120} />

      {/* Floating planet decoration */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-32 top-40 h-[420px] w-[420px] rounded-full opacity-70"
        style={{
          backgroundImage: `url(${planet})`,
          backgroundSize: "180%",
          backgroundPosition: "60% 50%",
          backgroundRepeat: "no-repeat",
          animation: "spin 90s linear infinite",
          filter: "drop-shadow(0 0 60px rgba(139,92,246,0.45))",
        }}
      />

      <div className="relative z-10">
        <Navbar active="CONTACT" />

        <main className="mx-auto w-full max-w-[1400px] px-8 pb-20 pt-6">
          <div className="grid gap-14 lg:grid-cols-2">
            {/* Left: heading + info */}
            <div className="animate-fade-up">
              <p className="text-[13px] font-semibold tracking-[0.25em] text-primary">
                08. CONTACT
              </p>
              <h1 className="mt-5 font-display text-5xl font-semibold leading-[1.05] text-foreground md:text-6xl">
                Let&rsquo;s create something
                <br />
                great <span className="text-gradient italic">together.</span>
              </h1>
              <p className="mt-6 max-w-md text-[15px] leading-relaxed text-muted-foreground">
                Feel free to reach out for project inquiries
                <br />
                or just a friendly hello!
              </p>

              <ul className="mt-10 space-y-5">
                {[
                  { Icon: Mail, text: "hello@avijitbiswas.dev" },
                  { Icon: PhoneCall, text: "+91 80166 42100" },
                  { Icon: MapPin, text: "Kolkata, India" },
                ].map(({ Icon, text }) => (
                  <li key={text} className="flex items-center gap-4">
                    <span className="grid h-11 w-11 place-items-center rounded-lg border border-primary/30 bg-primary/10 text-primary transition-all hover:scale-110 hover:border-primary hover:shadow-[0_0_20px_-4px_var(--primary)]">
                      <Icon className="h-5 w-5" />
                    </span>
                    <span className="text-[15px] font-medium text-foreground">{text}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-10 flex items-center gap-4">
                {[Github, Linkedin, Twitter, Instagram].map((Icon, i) => (
                  <a
                    key={i}
                    href="#"
                    className="grid h-12 w-12 place-items-center rounded-lg border border-border bg-card/40 text-foreground transition-all hover:-translate-y-1 hover:border-primary hover:text-primary hover:shadow-[0_0_24px_-6px_var(--primary)]"
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                ))}
              </div>
            </div>

            {/* Right: form */}
            <div
              className="glass animate-fade-up rounded-2xl p-8 md:p-10"
              style={{ animationDelay: "120ms" }}
            >
              <form
                className="space-y-5"
                onSubmit={(e) => {
                  e.preventDefault();
                }}
              >
                {[
                  { key: "name", label: "Your Name" },
                  { key: "email", label: "Your Email", type: "email" },
                  { key: "subject", label: "Subject" },
                ].map((f) => (
                  <input
                    key={f.key}
                    type={f.type ?? "text"}
                    placeholder={f.label}
                    value={form[f.key as keyof typeof form]}
                    onChange={(e) => setForm({ ...form, [f.key]: e.target.value })}
                    className="w-full rounded-xl border border-border bg-transparent px-5 py-4 text-[15px] text-foreground placeholder:text-muted-foreground/80 outline-none transition-all focus:border-primary focus:shadow-[0_0_24px_-8px_var(--primary)]"
                  />
                ))}
                <textarea
                  placeholder="Your Message"
                  rows={6}
                  value={form.message}
                  onChange={(e) => setForm({ ...form, message: e.target.value })}
                  className="w-full resize-none rounded-xl border border-border bg-transparent px-5 py-4 text-[15px] text-foreground placeholder:text-muted-foreground/80 outline-none transition-all focus:border-primary focus:shadow-[0_0_24px_-8px_var(--primary)]"
                />

                <button
                  type="submit"
                  className="group inline-flex items-center gap-3 rounded-xl bg-primary px-6 py-3.5 text-[13px] font-semibold tracking-[0.2em] text-primary-foreground transition-all hover:bg-primary-glow hover:shadow-[0_0_30px_-4px_var(--primary)]"
                >
                  SEND MESSAGE
                  <Send className="h-4 w-4 transition-transform group-hover:translate-x-1 group-hover:-translate-y-0.5" />
                </button>
              </form>
            </div>
          </div>

          {/* Bottom card */}
          <div
            className="glass mt-16 max-w-xl animate-fade-up rounded-2xl p-8"
            style={{ animationDelay: "240ms" }}
          >
            <h3 className="font-display text-2xl font-semibold text-foreground">
              Available for new projects.
            </h3>
            <p className="mt-3 max-w-md text-[15px] leading-relaxed text-muted-foreground">
              I&apos;m currently available for freelance projects and
              <br />
              full-time opportunities.
            </p>
            <button className="group mt-6 inline-flex items-center gap-3 rounded-lg bg-primary px-5 py-3 text-[12px] font-semibold tracking-[0.2em] text-primary-foreground transition-all hover:bg-primary-glow hover:shadow-[0_0_30px_-4px_var(--primary)]">
              HIRE ME
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </button>
          </div>
        </main>
      </div>
    </div>
  );
}
