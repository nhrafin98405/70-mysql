import { Link } from "@tanstack/react-router";
import { Plus } from "lucide-react";

const links = [
  { label: "HOME", href: "/" },
  { label: "ABOUT", href: "/about" },
  { label: "SKILLS", href: "/skills" },
  { label: "PROJECTS", href: "/projects" },
  { label: "EXPERIENCE", href: "/experience" },
  { label: "SERVICES", href: "/services" },
  { label: "BLOG", href: "/blog" },
  { label: "CONTACT", href: "/contact" },
];

export function Navbar({ active = "CONTACT" }: { active?: string }) {
  return (
    <header className="relative z-20 mx-auto flex w-full max-w-[1400px] items-center justify-between px-8 py-6">
      <Link to="/" className="flex items-center gap-3">
        <span className="grid h-10 w-10 place-items-center rounded-lg border border-primary/40 bg-primary/10 font-mono text-primary">
          {"</>"}
        </span>
        <span className="font-display text-lg font-semibold tracking-wide text-foreground">
          Avijit Biswas
        </span>
      </Link>

      <nav className="hidden items-center gap-8 lg:flex">
        {links.map((l) => {
          const isActive = l.label === active;
          return (
            <a
              key={l.label}
              href={l.href}
              className={`relative text-[13px] font-medium tracking-[0.18em] transition-colors ${
                isActive
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {l.label}
              {isActive && (
                <span className="absolute -bottom-2 left-0 h-[2px] w-6 bg-primary" />
              )}
            </a>
          );
        })}
      </nav>

      <div className="flex items-center gap-6">
        <button className="hidden text-muted-foreground transition-colors hover:text-primary lg:block">
          <Plus className="h-5 w-5" />
        </button>
        <a
          href="/contact"
          className="rounded-md border border-primary px-5 py-2.5 text-[12px] font-semibold tracking-[0.18em] text-primary transition-all hover:bg-primary hover:text-primary-foreground hover:shadow-[0_0_24px_-4px_var(--primary)]"
        >
          LET&apos;S TALK
        </a>
      </div>
    </header>
  );
}
