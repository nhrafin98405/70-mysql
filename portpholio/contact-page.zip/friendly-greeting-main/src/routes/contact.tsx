import { createFileRoute } from "@tanstack/react-router";
import { ContactPage } from "@/components/ContactPage";

export const Route = createFileRoute("/contact")({
  component: ContactPage,
  head: () => ({
    meta: [
      { title: "Contact — Avijit Biswas" },
      { name: "description", content: "Get in touch with Avijit Biswas for freelance projects and collaborations." },
    ],
  }),
});
