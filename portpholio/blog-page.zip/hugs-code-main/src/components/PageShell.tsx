import type { ReactNode } from "react";
import { Navbar } from "./Navbar";
import { SpaceBackground } from "./SpaceBackground";

export function PageShell({ children }: { children: ReactNode }) {
  return (
    <div className="relative min-h-screen">
      <SpaceBackground />
      <Navbar />
      <main className="relative z-10">{children}</main>
    </div>
  );
}
