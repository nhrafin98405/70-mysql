import bg from "@/assets/space-bg.png";

/**
 * Fixed space background image — positioned exactly as in the reference:
 * the nebula glow sits at the bottom-right of the viewport.
 */
export function SpaceBackground() {
  return (
    <div
      aria-hidden
      className="pointer-events-none fixed inset-0 -z-10"
      style={{
        backgroundImage: `url(${bg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
      }}
    >
      {/* dark vignette so content stays readable */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "radial-gradient(ellipse at 50% 0%, rgba(6,2,17,0.85) 0%, rgba(6,2,17,0.6) 40%, rgba(6,2,17,0.2) 100%)",
        }}
      />
    </div>
  );
}
