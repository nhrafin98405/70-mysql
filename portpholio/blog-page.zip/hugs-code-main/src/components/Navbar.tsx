import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const links = [
  { to: "/", label: "HOME" },
  { to: "/about", label: "ABOUT" },
  { to: "/skills", label: "SKILLS" },
  { to: "/projects", label: "PROJECTS" },
  { to: "/experience", label: "EXPERIENCE" },
  { to: "/services", label: "SERVICES" },
  { to: "/blog", label: "BLOG" },
  { to: "/contact", label: "CONTACT" },
] as const;

export function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="relative z-50">
      <div className="mx-auto max-w-7xl px-6 md:px-10 py-6">
        <nav className="flex items-center justify-between gap-6">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3">
            <span
              className="grid h-10 w-10 place-items-center rounded-xl"
              style={{
                background: "linear-gradient(135deg, #a855f7, #7c3aed)",
                boxShadow: "0 0 20px rgba(168,85,247,0.5)",
              }}
            >
              <span className="font-display font-bold text-white text-sm">{"</>"}</span>
            </span>
            <span className="font-display font-bold text-lg text-white">Avijit Biswas</span>
          </Link>

          {/* Desktop links */}
          <ul className="hidden lg:flex items-center gap-7">
            {links.map((l) => (
              <li key={l.to}>
                <Link
                  to={l.to}
                  activeOptions={{ exact: l.to === "/" }}
                  className="text-[11px] font-semibold tracking-[0.18em] text-white/70 hover:text-white transition-colors relative py-1"
                  activeProps={{
                    className:
                      "text-white relative py-1 after:content-[''] after:absolute after:left-0 after:right-0 after:-bottom-1 after:h-[2px] after:bg-gradient-to-r after:from-[#a855f7] after:to-[#7c3aed] after:rounded-full",
                  }}
                >
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>

          {/* CTA */}
          <div className="flex items-center gap-2">
            <Link to="/contact" className="hidden md:inline-flex btn-ghost-neon text-[11px] tracking-[0.18em]">
              LET'S TALK
            </Link>
            <button
              aria-label="Toggle menu"
              onClick={() => setOpen((o) => !o)}
              className="lg:hidden grid h-10 w-10 place-items-center rounded-full bg-white/5 ring-1 ring-white/10"
            >
              {open ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
            </button>
          </div>
        </nav>

        {open && (
          <div className="glass mt-3 lg:hidden p-4 animate-fade-up">
            <ul className="grid grid-cols-2 gap-2">
              {links.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    onClick={() => setOpen(false)}
                    className="block rounded-xl px-4 py-3 text-xs font-semibold tracking-[0.18em] text-white/70 hover:bg-white/5 hover:text-white"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </header>
  );
}
