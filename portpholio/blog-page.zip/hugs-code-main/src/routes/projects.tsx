import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/projects")({ component: Page });

function Page() {
  return (
    <PageShell>
      <section className="section">
        <div className="eyebrow">projects</div>
        <h1 className="h-display mt-5 text-white">Coming <span className="neon-text">soon.</span></h1>
      </section>
    </PageShell>
  );
}
