import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { Calendar, Clock, FolderOpen, ArrowRight } from "lucide-react";
import { useState } from "react";
import planet from "@/assets/planet.png";
import b1 from "@/assets/blog-1.jpg";
import b2 from "@/assets/blog-2.jpg";
import b3 from "@/assets/blog-3.jpg";

export const Route = createFileRoute("/blog")({
  component: Blog,
  head: () => ({
    meta: [
      { title: "Blog — Avijit Biswas" },
      { name: "description", content: "Thoughts, tutorials and things I love to share." },
    ],
  }),
});

const cats = ["All Posts", "Web Development", "Tutorials", "Career", "Tech News"] as const;

const posts = [
  {
    img: b1,
    title: "Understanding Server Components in Next.js 14",
    desc: "A deep dive into React Server Components and how they improve performance in Next.js 14.",
    date: "May 12, 2024",
    read: "3 min read",
    cat: "Web Development",
  },
  {
    img: b2,
    title: "Authentication in MERN Stack with JWT",
    desc: "Learn how to implement secure authentication using JWT in a MERN stack application.",
    date: "Apr 28, 2024",
    read: "7 min read",
    cat: "Tutorial",
  },
  {
    img: b3,
    title: "10 Tips to Write Clean and Better Code",
    desc: "Simple tips that help me write clean, maintainable and scalable code every day.",
    date: "Apr 15, 2024",
    read: "4 min read",
    cat: "Career",
  },
];

function Blog() {
  const [active, setActive] = useState<(typeof cats)[number]>("All Posts");
  const filtered =
    active === "All Posts"
      ? posts
      : posts.filter((p) => p.cat.toLowerCase().includes(active.toLowerCase().split(" ")[0]));

  return (
    <PageShell>
      <section className="section pt-4 md:pt-6">
        {/* Eyebrow */}
        <div className="eyebrow">01. BLOG</div>

        {/* Heading */}
        <h1 className="h-display mt-5 text-white">
          Thoughts, tutorials &amp;
          <br />
          things I love to share.
        </h1>

        {/* Category filters */}
        <div className="mt-10 flex flex-wrap gap-3">
          {cats.map((c) => {
            const isActive = active === c;
            return (
              <button
                key={c}
                onClick={() => setActive(c)}
                className={
                  isActive
                    ? "rounded-full px-6 py-3 text-sm font-semibold text-white transition-all"
                    : "rounded-full px-6 py-3 text-sm font-medium text-white/70 transition-all hover:text-white"
                }
                style={
                  isActive
                    ? {
                        background: "linear-gradient(135deg, #8b5cf6, #6d28d9)",
                        boxShadow: "0 0 30px -5px rgba(168,85,247,0.7)",
                      }
                    : {
                        background: "rgba(20,15,40,0.6)",
                        border: "1px solid rgba(255,255,255,0.08)",
                      }
                }
              >
                {c}
              </button>
            );
          })}
        </div>

        {/* Blog post list */}
        <div className="mt-10 space-y-5">
          {filtered.map((p) => (
            <article
              key={p.title}
              className="grid md:grid-cols-[260px_1fr] gap-6 p-4 md:p-5 rounded-2xl transition-all hover:-translate-y-0.5 group"
              style={{
                background: "rgba(15,10,30,0.55)",
                border: "1px solid rgba(255,255,255,0.06)",
                backdropFilter: "blur(14px)",
              }}
            >
              <div className="relative aspect-[16/10] md:aspect-auto md:h-[160px] overflow-hidden rounded-xl">
                <img
                  src={p.img}
                  alt={p.title}
                  loading="lazy"
                  width={520}
                  height={320}
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              <div className="flex flex-col justify-center">
                <h3 className="font-display text-xl md:text-2xl font-bold text-white leading-snug">
                  {p.title}
                </h3>
                <p className="mt-2.5 text-sm md:text-[15px] text-white/60 leading-relaxed">
                  {p.desc}
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-white/50">
                  <span className="inline-flex items-center gap-2">
                    <Calendar className="h-3.5 w-3.5" /> {p.date}
                  </span>
                  <span className="inline-flex items-center gap-2">
                    <FolderOpen className="h-3.5 w-3.5" /> {p.cat}
                  </span>
                  <span className="inline-flex items-center gap-2">
                    <Clock className="h-3.5 w-3.5" /> {p.read}
                  </span>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* Newsletter CTA — purple gradient card with rotating planet on right */}
        <div
          className="mt-12 relative overflow-hidden rounded-3xl p-8 md:p-12"
          style={{
            background:
              "linear-gradient(110deg, #4c1d95 0%, #5b21b6 35%, #6d28d9 65%, #1e1b4b 100%)",
            border: "1px solid rgba(168,85,247,0.35)",
          }}
        >
          {/* Rotating planet decoration on the right (positioned exactly like the reference) */}
          <div
            aria-hidden
            className="pointer-events-none absolute -right-16 -bottom-20 md:-right-10 md:-bottom-16 h-[340px] w-[340px] md:h-[420px] md:w-[420px] opacity-90"
          >
            <img
              src={planet}
              alt=""
              width={1500}
              height={1024}
              className="h-full w-full object-contain animate-spin-slower"
              style={{ filter: "drop-shadow(0 0 60px rgba(168,85,247,0.6))" }}
            />
          </div>
          {/* Star sparkles inside the card */}
          <div aria-hidden className="pointer-events-none absolute inset-0">
            {[
              { t: "20%", l: "55%", s: 2 },
              { t: "70%", l: "62%", s: 3 },
              { t: "40%", l: "78%", s: 2 },
              { t: "85%", l: "70%", s: 2 },
              { t: "30%", l: "88%", s: 3 },
            ].map((s, i) => (
              <span
                key={i}
                className="absolute rounded-full bg-white animate-twinkle"
                style={{
                  top: s.t,
                  left: s.l,
                  width: s.s,
                  height: s.s,
                  boxShadow: "0 0 8px rgba(255,255,255,0.9)",
                  animationDelay: `${i * 0.5}s`,
                }}
              />
            ))}
          </div>

          <div className="relative z-10 max-w-xl">
            <h3 className="font-display text-3xl md:text-4xl font-bold text-white">
              Stay curious, keep learning.
            </h3>
            <p className="mt-3 text-white/75 text-sm md:text-base">
              Subscribe to get updates on new posts and tutorials.
            </p>
            <form
              className="mt-6 flex flex-col sm:flex-row gap-3 max-w-md"
              onSubmit={(e) => e.preventDefault()}
            >
              <input
                type="email"
                required
                placeholder="Enter your email"
                className="flex-1 rounded-full bg-black/40 border border-white/15 px-5 py-3 text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-[#a855f7]"
              />
              <button className="rounded-full px-6 py-3 text-sm font-semibold text-white inline-flex items-center justify-center gap-2 transition-all hover:scale-[1.02]"
                style={{
                  background: "linear-gradient(135deg, #8b5cf6, #6d28d9)",
                  boxShadow: "0 0 30px -5px rgba(168,85,247,0.7)",
                }}
              >
                SUBSCRIBE <ArrowRight className="h-4 w-4" />
              </button>
            </form>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
