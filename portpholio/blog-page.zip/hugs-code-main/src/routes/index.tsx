import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <PageShell>
      <section className="section">
        <div className="eyebrow">Home</div>
        <h1 className="h-display mt-5 text-white">
          Coming <span className="neon-text">soon.</span>
        </h1>
        <p className="mt-4 text-white/60 max-w-xl">
          Open the <a href="/blog" className="text-[color:var(--color-neon)] underline">Blog</a> page to preview the pixel-perfect build.
        </p>
      </section>
    </PageShell>
  );
}
