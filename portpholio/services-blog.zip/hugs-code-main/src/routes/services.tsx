import { createFileRoute, Link } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import {
  Code2,
  Plug,
  Database,
  Zap,
  LayoutPanelTop,
  Bug,
  Target,
  Shield,
  MessageCircle,
  ArrowRight,
} from "lucide-react";
import planet from "@/assets/planet-2.png";
import cube from "@/assets/cube.png";
import asteroidSingle from "@/assets/asteroid-single.png";
import asteroidCluster from "@/assets/asteroid-cluster.png";

export const Route = createFileRoute("/services")({
  component: Services,
  head: () => ({
    meta: [
      { title: "Services — Avijit Biswas" },
      { name: "description", content: "Services I offer to help your business grow." },
    ],
  }),
});

const services = [
  { icon: Code2, title: "Web Application\nDevelopment", desc: "Full-stack web apps using modern technologies." },
  { icon: Plug, title: "API Development", desc: "RESTful API design and integration." },
  { icon: Database, title: "Database Design", desc: "Optimized and scalable database solutions." },
  { icon: Zap, title: "Performance\nOptimization", desc: "Make apps faster and better." },
  { icon: LayoutPanelTop, title: "UI/UX Implementation", desc: "Pixel-perfect and responsive designs." },
  { icon: Bug, title: "Bug Fixing &\nMaintenance", desc: "Ongoing support and bug fixes." },
];

const why = [
  { icon: Target, title: "Client-Focused Approach", desc: "Your goals are my priority. I deliver solutions that align with your vision." },
  { icon: Zap, title: "Fast & Reliable Delivery", desc: "I follow best practices to ensure high-quality solutions delivered on time." },
  { icon: Shield, title: "Secure & Scalable Code", desc: "I build secure, maintainable, and scalable applications." },
  { icon: MessageCircle, title: "Clear Communication", desc: "I believe in transparent communication and regular updates." },
];

function Services() {
  return (
    <PageShell>
      {/* Drifting asteroids — float across screen continuously */}
      <div aria-hidden className="pointer-events-none fixed inset-0 -z-[1] overflow-hidden">
        <img src={asteroidCluster} alt="" className="absolute top-[8%] w-[180px] opacity-80 animate-drift-rtl" style={{ animationDuration: "55s", filter: "drop-shadow(0 0 30px rgba(168,85,247,0.5))" }} />
        <img src={asteroidSingle} alt="" className="absolute top-[28%] w-[90px] opacity-70 animate-drift-ltr" style={{ animationDuration: "70s", animationDelay: "-20s", filter: "drop-shadow(0 0 20px rgba(168,85,247,0.5))" }} />
        <img src={asteroidSingle} alt="" className="absolute top-[48%] w-[60px] opacity-60 animate-drift-rtl" style={{ animationDuration: "45s", animationDelay: "-15s", filter: "drop-shadow(0 0 15px rgba(168,85,247,0.4))" }} />
        <img src={asteroidCluster} alt="" className="absolute top-[65%] w-[140px] opacity-70 animate-drift-ltr" style={{ animationDuration: "65s", animationDelay: "-30s", filter: "drop-shadow(0 0 25px rgba(168,85,247,0.5))" }} />
        <img src={asteroidSingle} alt="" className="absolute top-[82%] w-[110px] opacity-75 animate-drift-rtl" style={{ animationDuration: "60s", animationDelay: "-40s", filter: "drop-shadow(0 0 22px rgba(168,85,247,0.5))" }} />
        <img src={asteroidSingle} alt="" className="absolute top-[18%] w-[45px] opacity-55 animate-drift-rtl" style={{ animationDuration: "38s", animationDelay: "-10s", filter: "drop-shadow(0 0 12px rgba(168,85,247,0.4))" }} />
        <img src={asteroidCluster} alt="" className="absolute top-[55%] w-[80px] opacity-60 animate-drift-ltr" style={{ animationDuration: "50s", animationDelay: "-5s", filter: "drop-shadow(0 0 18px rgba(168,85,247,0.4))" }} />
        <img src={asteroidSingle} alt="" className="absolute top-[38%] w-[70px] opacity-65 animate-drift-ltr" style={{ animationDuration: "58s", animationDelay: "-45s", filter: "drop-shadow(0 0 18px rgba(168,85,247,0.45))" }} />
      </div>

      {/* Planets — top right, small planet orbits the big one like a moon */}
      <div aria-hidden className="pointer-events-none absolute right-0 top-0 -z-[1] hidden md:block">
        <div className="relative w-[680px] h-[520px]">
          {/* Big planet (center of orbit system) */}
          <div className="absolute right-[40px] top-[60px] w-[340px] h-[340px]">
            <img
              src={planet}
              alt=""
              className="absolute inset-0 w-full h-full object-contain animate-spin-slower"
              style={{ filter: "drop-shadow(0 0 80px rgba(139,92,246,0.45))" }}
            />
            {/* Orbit ring — rotates the moon around big planet's center */}
            <div className="absolute inset-0 animate-orbit">
              {/* Position the moon at orbit radius from center */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[70px] h-[70px] -mt-[140px]">
                {/* Counter-rotate orbit, then spin moon on its own axis */}
                <div className="w-full h-full animate-orbit-counter">
                  <img
                    src={planet}
                    alt=""
                    className="w-full h-full object-contain animate-spin-slow"
                    style={{ filter: "drop-shadow(0 0 30px rgba(168,85,247,0.55))" }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <section className="section pt-4 md:pt-8">
        <div className="eyebrow">01. Services</div>
        <h1 className="h-display mt-5 text-white max-w-3xl">
          Services I offer to help<br />your business <span className="neon-text">grow.</span>
        </h1>

        {/* Main grid */}
        <div className="mt-12 grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Service cards — 2 cols of the 3 */}
          <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-5">
            {services.map((s) => (
              <article
                key={s.title}
                className="glass p-6 transition-transform hover:-translate-y-1 hover:border-[rgba(168,85,247,0.4)]"
              >
                <div
                  className="grid h-12 w-12 place-items-center rounded-xl mb-6"
                  style={{
                    background: "rgba(139,92,246,0.12)",
                    border: "1px solid rgba(168,85,247,0.35)",
                  }}
                >
                  <s.icon className="h-6 w-6 text-[#c4b5fd]" strokeWidth={1.6} />
                </div>
                <h3 className="text-white font-display text-lg leading-snug whitespace-pre-line">
                  {s.title}
                </h3>
                <p className="mt-3 text-sm text-white/60 leading-relaxed">{s.desc}</p>
              </article>
            ))}
          </div>

          {/* Why work with me */}
          <aside className="glass p-7 self-start">
            <h2 className="text-white font-display text-xl mb-6">Why work with me?</h2>
            <ul className="space-y-5">
              {why.map((w) => (
                <li key={w.title} className="flex gap-4">
                  <div
                    className="shrink-0 grid h-11 w-11 place-items-center rounded-xl"
                    style={{
                      background: "rgba(139,92,246,0.12)",
                      border: "1px solid rgba(168,85,247,0.3)",
                    }}
                  >
                    <w.icon className="h-5 w-5 text-[#c4b5fd]" strokeWidth={1.6} />
                  </div>
                  <div>
                    <h4 className="text-white font-semibold text-[15px]">{w.title}</h4>
                    <p className="mt-1 text-[13px] text-white/60 leading-relaxed">{w.desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </aside>
        </div>

        {/* CTA banner */}
        <div
          className="mt-10 rounded-2xl p-6 md:p-7 flex flex-col md:flex-row items-center gap-6 md:gap-8"
          style={{
            background:
              "linear-gradient(90deg, rgba(76,29,149,0.45) 0%, rgba(124,58,237,0.25) 100%)",
            border: "1px solid rgba(168,85,247,0.35)",
          }}
        >
          <img
            src={cube}
            alt=""
            className="h-20 w-20 md:h-24 md:w-24 object-contain animate-spin-slow"
            style={{ filter: "drop-shadow(0 0 25px rgba(168,85,247,0.6))" }}
          />
          <div className="flex-1 text-center md:text-left">
            <h3 className="text-white font-display text-xl md:text-2xl">
              Let's build something amazing together.
            </h3>
            <p className="mt-1 text-sm text-white/65">
              I'm available for freelance projects and full-time opportunities.
            </p>
          </div>
          <Link to="/contact" className="btn-neon text-[12px] tracking-[0.18em]">
            LET'S TALK <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </PageShell>
  );
}
