import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Code2,
  Lock,
  Lightbulb,
  Users,
  Eye,
  Compass,
  Rocket,
  FolderKanban,
  UsersRound,
  Star,
  Flame,
  Award,
  BadgeCheck,
  UserPlus,
  ArrowRight,
  User as UserIcon,
} from "lucide-react";
import portrait from "@/assets/avijit-portrait.jpeg";
import portal from "@/assets/portal-circle.png";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Avijit Biswas" },
      { name: "description", content: "About Avijit Biswas — Full-Stack MERN Developer building digital solutions that make a difference." },
      { property: "og:title", content: "About — Avijit Biswas" },
      { property: "og:description", content: "Full-Stack MERN Developer crafting fast, scalable, user-centric web apps." },
    ],
  }),
  component: AboutPage,
});

const NAV = ["Home", "About", "Skills", "Experience", "Services", "Blog", "Contact"];

const SKILLS: { name: string; pct: number; color: string; letters: string; bg: string }[] = [
  { name: "React.js", pct: 90, color: "#61DAFB", letters: "⚛", bg: "rgba(97,218,251,0.1)" },
  { name: "Next.js", pct: 88, color: "#ffffff", letters: "N|X", bg: "rgba(255,255,255,0.06)" },
  { name: "TypeScript", pct: 86, color: "#3178C6", letters: "Ts", bg: "rgba(49,120,198,0.15)" },
  { name: "Node.js", pct: 90, color: "#3C873A", letters: "⬢", bg: "rgba(60,135,58,0.15)" },
  { name: "Express.js", pct: 86, color: "#cbd5e1", letters: "ex", bg: "rgba(203,213,225,0.1)" },
  { name: "MongoDB", pct: 88, color: "#47A248", letters: "🍃", bg: "rgba(71,162,72,0.15)" },
  { name: "PostgreSQL", pct: 85, color: "#336791", letters: "🐘", bg: "rgba(51,103,145,0.2)" },
  { name: "Tailwind CSS", pct: 90, color: "#38BDF8", letters: "≋", bg: "rgba(56,189,248,0.12)" },
];

function AboutPage() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Header */}
      <header className="absolute inset-x-0 top-0 z-30 px-8 lg:px-12 py-6 flex items-center justify-between">
        <Link to="/about" className="flex items-center gap-3">
          <span className="grid place-items-center w-10 h-10 rounded-lg border border-[color:var(--neon)]/40 text-[color:var(--neon)]">
            <Code2 className="w-5 h-5" />
          </span>
          <span className="font-display text-xl font-semibold tracking-tight">Avijit Biswas</span>
        </Link>
        <nav className="hidden lg:flex items-center gap-9 text-[13px] font-medium tracking-[0.18em]">
          {NAV.map((n) => {
            const active = n === "About";
            return (
              <a
                key={n}
                href="#"
                className={`relative uppercase transition-colors ${active ? "text-[color:var(--neon)]" : "text-foreground/85 hover:text-white"}`}
              >
                {n}
                {active && (
                  <span className="absolute -bottom-2 left-0 right-0 h-[2px] bg-[color:var(--neon)] rounded-full" />
                )}
              </a>
            );
          })}
        </nav>
        <button className="px-6 py-2.5 rounded-md border border-[color:var(--neon)] text-[color:var(--neon)] text-[13px] font-semibold tracking-[0.2em] uppercase hover:bg-[color:var(--neon)]/10 transition-colors">
          Let's Talk
        </button>
      </header>

      {/* Main 4-column area */}
      <section className="relative pt-32 pb-10 px-8 lg:px-12">
        <div className="grid grid-cols-12 gap-8 max-w-[1500px] mx-auto">
          {/* Col 1: About text */}
          <div className="col-span-12 lg:col-span-3 space-y-6">
            <p className="text-[color:var(--neon)] text-sm font-semibold tracking-[0.25em]">01. ABOUT ME</p>
            <h2 className="font-display text-[40px] leading-[1.1] font-bold">
              Designing & building digital solutions that{" "}
              <span className="bg-gradient-to-r from-[color:var(--neon)] to-pink-400 bg-clip-text text-transparent">
                make a difference.
              </span>
            </h2>
            <p className="text-muted-foreground text-[15px] leading-relaxed">
              I'm passionate about building products that bridge efficiency, scalable and user-centric experiences.
            </p>
            <p className="text-muted-foreground text-[15px] leading-relaxed">
              I specialize in the MERN stack and modern technologies to create fast, secure and scalable web applications.
            </p>

            <ul className="space-y-3 pt-2">
              {[
                { icon: Lock, label: "Clean Code" },
                { icon: Lightbulb, label: "Problem Solver" },
                { icon: Users, label: "Team Player" },
                { icon: Eye, label: "Detail Orientated" },
                { icon: Compass, label: "Always Curious" },
              ].map(({ icon: Icon, label }) => (
                <li key={label} className="flex items-center gap-3 text-[15px]">
                  <span className="grid place-items-center w-7 h-7 rounded-full border border-[color:var(--neon)]/50 text-[color:var(--neon)]">
                    <Icon className="w-3.5 h-3.5" />
                  </span>
                  {label}
                </li>
              ))}
            </ul>

            <button className="mt-2 inline-flex items-center gap-2 px-6 py-3 rounded-md bg-gradient-to-r from-[color:var(--neon-2)] to-[color:var(--neon)] text-white text-[13px] font-semibold tracking-[0.2em] uppercase shadow-[0_10px_40px_-10px_rgba(168,85,247,0.6)]">
              More About Me <UserIcon className="w-4 h-4" />
            </button>
          </div>

          {/* Col 2: Portrait + portal */}
          <div className="col-span-12 lg:col-span-4 flex justify-center">
            <div className="relative w-[360px]">
              {/* Portrait card */}
              <div className="relative rounded-[28px] p-[2px] bg-gradient-to-b from-[color:var(--neon)] via-[color:var(--neon-2)] to-fuchsia-500 shadow-[0_0_60px_-10px_rgba(168,85,247,0.7)]">
                <div className="rounded-[26px] overflow-hidden bg-background">
                  <img src={portrait} alt="Avijit Biswas" className="w-full h-[520px] object-cover" />
                </div>
                {/* glow */}
                <div className="pointer-events-none absolute inset-0 rounded-[28px] ring-1 ring-[color:var(--neon)]/40 shadow-[inset_0_0_40px_rgba(168,85,247,0.35)]" />
              </div>

              {/* Portal under image */}
              <div className="absolute left-1/2 -translate-x-1/2 -bottom-24 w-[520px] h-[200px] pointer-events-none select-none">
                <img
                  src={portal}
                  alt=""
                  className="w-full h-full object-contain animate-spin-slow"
                  style={{ mixBlendMode: "screen" }}
                />
              </div>
            </div>
          </div>

          {/* Col 3: Skills */}
          <div className="col-span-12 lg:col-span-3 space-y-6">
            <p className="text-[color:var(--neon)] text-sm font-semibold tracking-[0.25em]">02. MY SKILLS</p>
            <h3 className="font-display text-[28px] leading-[1.2] font-bold">
              Technologies I work with to bring ideas to life.
            </h3>
            <div className="space-y-4 pt-2">
              {SKILLS.map((s) => (
                <div key={s.name}>
                  <div className="flex items-center gap-3 mb-1.5">
                    <span
                      className="grid place-items-center w-7 h-7 rounded-md text-[11px] font-bold"
                      style={{ background: s.bg, color: s.color }}
                    >
                      {s.letters}
                    </span>
                    <span className="text-[14px] font-medium flex-1">{s.name}</span>
                    <span className="text-[13px] text-muted-foreground">{s.pct}%</span>
                  </div>
                  <div className="h-[3px] rounded-full bg-white/10 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-[color:var(--neon-2)] to-pink-400"
                      style={{ width: `${s.pct}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Col 4: Achievements + CTA */}
          <div className="col-span-12 lg:col-span-2 space-y-5">
            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-sm">
              <h4 className="font-display text-lg font-semibold mb-4">Achievements</h4>
              <ul className="space-y-4">
                {[
                  { Icon: Flame, color: "#f97316", title: "Top 1% on LeetCode", sub: "Solved 150+ DSA problems" },
                  { Icon: Star, color: "#facc15", title: "3+ Years of Experience", sub: "Building scalable solutions" },
                  { Icon: Award, color: "#a855f7", title: "Best Full-Stack Developer", sub: "Award by my university" },
                  { Icon: UserPlus, color: "#22c55e", title: "Open Source Contributor", sub: "Actively contributing to OSS" },
                ].map(({ Icon, color, title, sub }) => (
                  <li key={title} className="flex items-start gap-3">
                    <Icon className="w-5 h-5 mt-0.5 shrink-0" style={{ color }} />
                    <div>
                      <p className="text-[13px] font-semibold text-[color:var(--neon)]">{title}</p>
                      <p className="text-[12px] text-muted-foreground">{sub}</p>
                    </div>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5 backdrop-blur-sm">
              <h4 className="font-display text-lg font-semibold mb-2">Let's Work Together</h4>
              <p className="text-[12.5px] text-muted-foreground leading-relaxed mb-4">
                Have a project in mind? Let's discuss and build something amazing together.
              </p>
              <button className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-md bg-gradient-to-r from-[color:var(--neon-2)] to-[color:var(--neon)] text-white text-[12px] font-semibold tracking-[0.2em] uppercase">
                Let's Connect <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats row */}
      <section className="px-8 lg:px-12 pt-20 pb-12">
        <div className="max-w-[1500px] mx-auto grid grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            { Icon: Rocket, n: "3+", label: "Years Experience" },
            { Icon: FolderKanban, n: "20+", label: "Projects Completed" },
            { Icon: UsersRound, n: "15+", label: "Happy Clients" },
            { Icon: Star, n: "5★", label: "Client Rating" },
          ].map(({ Icon, n, label }) => (
            <div
              key={label}
              className="rounded-2xl border border-white/10 bg-white/[0.03] backdrop-blur-sm p-7 flex items-center gap-5"
            >
              <Icon className="w-10 h-10 text-[color:var(--neon)]" strokeWidth={1.5} />
              <div>
                <p className="font-display text-3xl font-bold">{n}</p>
                <p className="text-[13px] text-muted-foreground">{label}</p>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
