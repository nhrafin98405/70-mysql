import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Code2,
  Atom,
  Triangle,
  FileType2,
  Boxes,
  Server,
  Leaf,
  Database,
  Wind,
  Download,
  Star,
  CircleDot,
} from "lucide-react";
import bgImg from "@/assets/main_bg.png";
import planetImg from "@/assets/planet.png";
import asteroidsImg from "@/assets/multi_asteroid.png";
import singleAsteroid from "@/assets/single_asteroid.png";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Avijit Biswas — Full Stack Developer" },
      {
        name: "description",
        content:
          "Avijit Biswas — Full Stack Developer building scalable, secure & user-friendly web applications.",
      },
      { property: "og:title", content: "Avijit Biswas — Full Stack Developer" },
      {
        property: "og:description",
        content:
          "Full Stack Developer with 3+ years of experience building exceptional digital experiences.",
      },
    ],
  }),
  component: Home,
});

const NAV = ["HOME", "ABOUT", "SKILLS", "EXPERIENCE", "SERVICES", "BLOG", "CONTACT"];

function StarField() {
  const stars = useMemo(
    () =>
      Array.from({ length: 90 }).map(() => ({
        top: Math.random() * 100,
        left: Math.random() * 100,
        size: Math.random() * 2 + 0.5,
        delay: Math.random() * 4,
        duration: 2 + Math.random() * 3,
      })),
    [],
  );
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {stars.map((s, i) => (
        <span
          key={i}
          className="absolute rounded-full bg-white animate-twinkle"
          style={{
            top: `${s.top}%`,
            left: `${s.left}%`,
            width: `${s.size}px`,
            height: `${s.size}px`,
            animationDelay: `${s.delay}s`,
            animationDuration: `${s.duration}s`,
            boxShadow: "0 0 6px rgba(200,170,255,0.7)",
          }}
        />
      ))}
    </div>
  );
}

function Navbar() {
  const [active, setActive] = useState("HOME");
  return (
    <header className="absolute top-0 left-0 right-0 z-30">
      <div className="mx-auto flex max-w-[1500px] items-center justify-between px-8 py-7">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-purple-400/40 bg-purple-500/10">
            <Code2 className="h-5 w-5 text-purple-300" strokeWidth={2.4} />
          </div>
          <span className="font-display text-xl font-semibold tracking-tight text-white">
            Avijit Biswas
          </span>
        </div>

        <nav className="hidden items-center gap-10 lg:flex">
          {NAV.map((item) => (
            <button
              key={item}
              onClick={() => setActive(item)}
              className={`nav-link ${active === item ? "active" : ""}`}
            >
              {item}
            </button>
          ))}
        </nav>

        <button className="rounded-md border border-purple-400/70 px-6 py-3 text-xs font-semibold tracking-[0.18em] text-purple-200 transition hover:bg-purple-500/10 hover:text-white">
          LET'S TALK
        </button>
      </div>
    </header>
  );
}

function StatRow({ value, accent, label, last }: { value: string; accent?: string; label: string; last?: boolean }) {
  return (
    <div className={last ? "" : "border-b border-white/5 pb-6"}>
      <div className="font-display text-5xl font-semibold text-white">
        {value}
        {accent && <span className="text-purple-400">{accent}</span>}
      </div>
      <div className="mt-2 text-sm text-purple-200/70">{label}</div>
    </div>
  );
}

function TechPill({ icon, label, color }: { icon: React.ReactNode; label: string; color?: string }) {
  return (
    <div className="tech-pill flex items-center gap-2 rounded-full px-4 py-2.5">
      <span style={{ color }}>{icon}</span>
      <span className="text-sm font-medium text-white/90">{label}</span>
    </div>
  );
}

function Home() {
  const heroRef = useRef<HTMLDivElement>(null);
  const [scroll, setScroll] = useState(0);

  useEffect(() => {
    const onScroll = () => setScroll(window.scrollY);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div ref={heroRef} className="relative min-h-screen overflow-hidden bg-[#050010] text-white">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url(${bgImg})`,
          transform: `translateY(${scroll * 0.2}px)`,
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#050010]/40 via-[#0a0420]/60 to-[#050010]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_left_top,rgba(80,30,180,0.25),transparent_55%)]" />

      <StarField />

      {/* Planet */}
      <div
        className="pointer-events-none absolute -right-[6%] top-[2%] z-10 w-[58vw] max-w-[900px] animate-pulse-glow"
        style={{ transform: `translateY(${scroll * -0.05}px)` }}
      >
        <img
          src={planetImg}
          alt="planet"
          className="w-full animate-spin-slow"
          style={{ filter: "drop-shadow(0 0 80px rgba(139,92,246,0.55))" }}
        />
      </div>

      {/* Floating asteroid clusters */}
      <img
        src={asteroidsImg}
        alt=""
        aria-hidden
        className="pointer-events-none absolute right-[18%] top-[36%] z-10 w-[160px] opacity-90 animate-float-slow"
        style={{ filter: "drop-shadow(0 0 20px rgba(139,92,246,0.5))" }}
      />
      <img
        src={singleAsteroid}
        alt=""
        aria-hidden
        className="pointer-events-none absolute right-[32%] top-[22%] z-10 w-[110px] opacity-90 animate-float-mid"
        style={{ filter: "drop-shadow(0 0 16px rgba(139,92,246,0.45))" }}
      />
      <img
        src={singleAsteroid}
        alt=""
        aria-hidden
        className="pointer-events-none absolute right-[44%] top-[55%] z-10 w-[90px] opacity-80 animate-drift"
        style={{ filter: "drop-shadow(0 0 14px rgba(139,92,246,0.4))" }}
      />

      <Navbar />

      {/* Hero */}
      <main className="relative z-20 mx-auto flex max-w-[1500px] flex-col px-8 pt-36 lg:pt-40">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-[1fr_320px]">
          {/* Left */}
          <div className="animate-fade-up">
            <div className="text-sm font-semibold tracking-[0.28em] text-purple-400">
              FULL STACK DEVELOPER
            </div>

            <h1 className="mt-6 font-display text-[64px] leading-[1.05] font-semibold text-white">
              Hi, I'm Avijit <span className="animate-wave inline-block">👋</span>
              <br />
              I build scalable, secure &amp;
              <br />
              user-friendly{" "}
              <span className="neon-text">web applications</span>.
            </h1>

            <p className="mt-8 max-w-xl text-base leading-relaxed text-purple-100/70">
              Full Stack Developer with 3+ years of experience
              <br /> building exceptional digital experiences.
            </p>

            <div className="mt-10 flex flex-wrap items-center gap-4">
              <button className="btn-neon rounded-md px-7 py-4 text-xs font-semibold tracking-[0.2em]">
                VIEW MY WORK
              </button>
              <button className="btn-ghost-neon flex items-center gap-2 rounded-md px-7 py-4 text-xs font-semibold tracking-[0.2em]">
                DOWNLOAD CV <Download className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-20 flex items-center gap-3 text-purple-200/70">
              <CircleDot className="h-6 w-6 text-purple-400" />
              <span className="text-xs font-semibold tracking-[0.25em]">SCROLL TO EXPLORE</span>
            </div>
          </div>

          {/* Right Stats */}
          <aside className="glass-card relative z-20 mt-2 hidden h-fit flex-col gap-6 rounded-2xl p-8 lg:flex">
            <StatRow value="3" accent="+" label="Years Experience" />
            <StatRow value="20" accent="+" label="Projects Completed" />
            <StatRow value="15" accent="+" label="Happy Clients" />
            <div>
              <div className="flex items-baseline gap-1 font-display text-5xl font-semibold text-white">
                5<Star className="h-6 w-6 translate-y-[-4px] fill-white text-white" />
              </div>
              <div className="mt-2 text-sm text-purple-200/70">Client Rating</div>
            </div>
          </aside>
        </div>

        {/* Tech Stack */}
        <div className="mt-16 mb-10 rounded-2xl border border-purple-400/15 bg-[#0a0420]/60 px-6 py-4 backdrop-blur-md">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <TechPill icon={<Atom className="h-4 w-4" />} label="React" color="#61dafb" />
            <TechPill icon={<Triangle className="h-4 w-4 fill-white" />} label="Next.js" color="#fff" />
            <TechPill icon={<FileType2 className="h-4 w-4" />} label="TypeScript" color="#3178c6" />
            <TechPill icon={<Boxes className="h-4 w-4" />} label="Node.js" color="#3c873a" />
            <TechPill icon={<Server className="h-4 w-4" />} label="Express.js" color="#fff" />
            <TechPill icon={<Leaf className="h-4 w-4" />} label="MongoDB" color="#13aa52" />
            <TechPill icon={<Database className="h-4 w-4" />} label="PostgreSQL" color="#6ea4d8" />
            <TechPill icon={<Wind className="h-4 w-4" />} label="Tailwind CSS" color="#38bdf8" />
          </div>
        </div>
      </main>
    </div>
  );
}
