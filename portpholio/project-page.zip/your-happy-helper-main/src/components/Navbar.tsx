import { useLocation } from "@tanstack/react-router";

const links = [
  { to: "/", label: "HOME" },
  { to: "/about", label: "ABOUT" },
  { to: "/skills", label: "SKILLS" },
  { to: "/experience", label: "EXPERIENCE" },
  { to: "/projects", label: "PROJECTS" },
  { to: "/blog", label: "BLOG" },
  { to: "/contact", label: "CONTACT" },
] as const;

export function Navbar() {
  const { pathname } = useLocation();
  return (
    <header className="relative z-50">
      <div className="mx-auto max-w-[1400px] px-6 md:px-10 pt-6">
        <nav className="flex items-center justify-between gap-6">
          <a href="/" className="flex items-center gap-2.5 font-display font-bold">
            <span className="text-[color:var(--color-neon)] text-xl">&lt;/&gt;</span>
            <span className="text-white text-lg tracking-tight">Avijit Biswas</span>
          </a>
          <ul className="hidden lg:flex items-center gap-8">
            {links.map((l) => {
              const active = pathname === l.to;
              return (
                <li key={l.to}>
                  <a
                    href={l.to}
                    className={`text-sm font-semibold tracking-[0.18em] transition-colors relative ${
                      active
                        ? "text-[color:var(--color-neon-strong)]"
                        : "text-white/85 hover:text-white"
                    }`}
                  >
                    {l.label}
                    {active && (
                      <span className="absolute -bottom-2 left-0 right-0 h-0.5 rounded-full bg-[color:var(--color-neon-strong)]" />
                    )}
                  </a>
                </li>
              );
            })}
          </ul>
          <a href="/contact" className="btn-outline-neon">
            LET'S TALK
          </a>
        </nav>
      </div>
    </header>
  );
}
