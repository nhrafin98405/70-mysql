import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  if (typeof window !== "undefined") {
    window.location.replace("/projects");
  }
  return (
    <div className="min-h-screen grid place-items-center bg-[#07060f] text-white/70">
      Redirecting to projects…
    </div>
  );
}
