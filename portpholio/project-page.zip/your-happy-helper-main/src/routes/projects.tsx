import { createFileRoute } from "@tanstack/react-router";
import { PageShell } from "@/components/PageShell";
import { ArrowRight } from "lucide-react";
import { useState } from "react";
import planet from "@/assets/planet.png";
import planetGlow from "@/assets/planet-glow-star.png";
import projectBg from "@/assets/project-bg.png";
import p1 from "@/assets/project-1.jpg";
import p2 from "@/assets/project-2.jpg";
import p3 from "@/assets/project-3.jpg";
import p4 from "@/assets/project-4.jpg";

export const Route = createFileRoute("/projects")({
  component: Projects,
  head: () => ({
    meta: [
      { title: "Projects — Avijit Biswas" },
      { name: "description", content: "A showcase of projects that made an impact." },
    ],
  }),
});

const cats = ["All", "Web Apps", "E-commerce", "Dashboard", "Full Stack"] as const;

const projects = [
  {
    img: p1,
    title: "DevBoard",
    desc: "Project management tool for developers to manage tasks, collaborate and track progress.",
    tags: ["Next.js", "TypeScript", "PostgreSQL"],
    cat: "Dashboard",
  },
  {
    img: p2,
    title: "ShopHub",
    desc: "Full-featured e-commerce platform with user authentication and admin dashboard.",
    tags: ["MERN Stack", "Stripe", "Redux"],
    cat: "E-commerce",
  },
  {
    img: p3,
    title: "TaskFlow",
    desc: "Task management app with drag & drop, filters and real-time collaboration.",
    tags: ["React", "Tailwind CSS", "DND Kit"],
    cat: "Web Apps",
  },
  {
    img: p4,
    title: "Chatify",
    desc: "Real-time chat application with private rooms and channel systems.",
    tags: ["Socket.io", "Express", "MongoDB"],
    cat: "Full Stack",
  },
];

function Projects() {
  const [active, setActive] = useState<(typeof cats)[number]>("All");
  const filtered = active === "All" ? projects : projects.filter((p) => p.cat === active);

  return (
    <PageShell>
      <section className="relative">
        {/* Hero with planet */}
        <div className="relative">
          {/* Planet decoration top-right */}
          <div className="pointer-events-none absolute -top-10 right-0 w-[55%] max-w-[780px] aspect-square">
            <img
              src={projectBg}
              alt=""
              className="absolute inset-0 h-full w-full object-cover opacity-60 [mask-image:radial-gradient(circle_at_center,black_40%,transparent_75%)]"
            />
            <img
              src={planet}
              alt=""
              className="absolute inset-0 m-auto h-[78%] w-[78%] object-contain animate-spin-slower"
            />
          </div>

          <div className="relative mx-auto max-w-[1400px] px-6 md:px-10 pt-16 md:pt-24">
            <div className="eyebrow">01. MY PROJECTS</div>
            <h1 className="h-display mt-5 max-w-3xl">
              A showcase of projects <br />
              that made an <span className="neon-text">impact</span>.
            </h1>

            {/* Filter pills */}
            <div className="mt-10 flex flex-wrap gap-3">
              {cats.map((c) => (
                <button
                  key={c}
                  onClick={() => setActive(c)}
                  className={`rounded-full px-6 py-2.5 text-sm font-medium transition-all ${
                    active === c
                      ? "bg-gradient-to-r from-[#7c3aed] to-[#a855f7] text-white shadow-[0_0_30px_-5px_rgba(168,85,247,0.7)]"
                      : "bg-white/[0.04] ring-1 ring-white/10 text-white/80 hover:text-white hover:ring-white/25"
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Project cards grid */}
        <div className="relative mx-auto max-w-[1400px] px-6 md:px-10 mt-12">
          <div className="grid md:grid-cols-2 gap-6">
            {filtered.map((p) => (
              <article
                key={p.title}
                className="glass-card p-5 flex flex-col sm:flex-row gap-5 transition hover:ring-1 hover:ring-[color:var(--color-neon)]/40"
              >
                <div className="sm:w-[44%] shrink-0 overflow-hidden rounded-xl">
                  <div className="aspect-[4/3] bg-black/40">
                    <img
                      src={p.img}
                      alt={p.title}
                      loading="lazy"
                      className="h-full w-full object-cover"
                    />
                  </div>
                </div>
                <div className="flex-1 min-w-0 flex flex-col">
                  <h3 className="font-display text-2xl text-white">{p.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-white/65">{p.desc}</p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {p.tags.map((t) => (
                      <span
                        key={t}
                        className="text-xs rounded-md px-3 py-1 bg-white/[0.04] ring-1 ring-white/10 text-white/85"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                  <a
                    href="#"
                    className="mt-5 inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.18em] text-[color:var(--color-neon-strong)] hover:text-white transition"
                  >
                    View Case Study <ArrowRight className="h-3.5 w-3.5" />
                  </a>
                </div>
              </article>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="relative mt-10 overflow-hidden rounded-2xl border border-[rgba(168,85,247,0.35)] bg-gradient-to-r from-[#1a0f3a]/80 via-[#1d1147]/80 to-[#1a0f3a]/80 p-6 md:p-8">
            <img
              src={planetGlow}
              alt=""
              className="pointer-events-none absolute -left-8 top-1/2 -translate-y-1/2 h-24 w-24 object-contain opacity-90 animate-spin-slow"
            />
            <img
              src={planetGlow}
              alt=""
              className="pointer-events-none absolute right-4 -bottom-6 h-20 w-20 object-contain opacity-80 animate-spin-slower"
            />
            <div className="relative flex flex-col md:flex-row items-center justify-between gap-6 pl-0 md:pl-24">
              <div>
                <h3 className="font-display text-xl md:text-2xl text-white">
                  Have an idea for a project?
                </h3>
                <p className="text-sm text-white/65 mt-1">
                  Let's turn your ideas into real, scalable and great designs.
                </p>
              </div>
              <a href="/contact" className="btn-neon shrink-0">
                LET'S WORK TOGETHER <ArrowRight className="h-4 w-4" />
              </a>
            </div>
          </div>
        </div>
      </section>
    </PageShell>
  );
}
